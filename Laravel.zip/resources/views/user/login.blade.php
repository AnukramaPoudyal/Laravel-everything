<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel ="stylesheet" type="text/css" href="{{asset('css/style.css')}}">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <title>Login</title>
</head>

<body>

    
	<div class="form">
          
      <ul class="tab-group">
        <li class="tab active"><a href="#signup">Sign Up</a></li>
        <li class="tab"><a href="#login">Log In</a></li>
      </ul>
      
      <div class="tab-content">
        <div id="signup">   
          <h1>Hey New User! </h1>
          @if ($errors->any())
     @foreach ($errors->all() as $error)
         <div style="color: red">{{$error}}</div>
         <br>
     @endforeach
 @endif
          <form method="POST" action="/register">
            @csrf
            <div class="field-wrap">
              <label>
                 Name<span class="req">*</span>
              </label>
              <input type="text" required autocomplete="off" name="name"/>
            </div>

          <div class="field-wrap">
            <label>
              Email Address<span class="req">*</span>
            </label>
            <input type="email"required autocomplete="off" name="email"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Set A Password<span class="req">*</span>
            </label>
            <input type="password"required autocomplete="off" name="password"/>
          </div>

          <div class="field-wrap">
            <label>
              Re-type The Password<span class="req">*</span>
            </label>
            <input type="password"required autocomplete="off" name="password_confirmation"/>
          </div>
          
          <button type="submit" class="button button-block"/>Lets Go!!</button>
      
          </form>
</div> 
        
        <div id="login">   
          <h1>Welcome Back!</h1>
          @if ($errors->any())
     @foreach ($errors->all() as $error)
         <div style="color: red">{{$error}}</div>
         <br>
     @endforeach
 @endif
          <form action="/login" method="post">
            @csrf
            <div class="field-wrap">
            <label>
              Email Address<span class="req">*</span>
            </label>
            <input type="email"required autocomplete="off" name="email"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Password<span class="req">*</span>
            </label>
            <input type="password"required autocomplete="off" name='password'/>
          </div>
          
          
          <button class="button button-block">Lets Go!!</button>
          
</div>
</div>

    </div>
        
</div> <!-- /form -->
<script src="{{asset('js/script.js')}}"></script>
</body>
</html>


