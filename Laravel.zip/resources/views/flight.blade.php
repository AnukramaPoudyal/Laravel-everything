<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ $flight->airplane->name }}</title>
</head>
<body>

@if (session()->has('message'))
    <div>{{ session()->get("message") }}</div>
@endif
    <h1>{{ $flight->from }} to {{ $flight->to }} in {{ $flight->airplane->name }}</h1>
    <p>Flight Model : {{ $flight->airplane->model }}</p>
    <p>Flight Type : {{ $flight->airplane->type }}</p>
    <p>Time : {{ $flight->time }}</p>
    <p>Price : {{ $flight->price }}</p>
    <p>Total seats : {{ $flight->airplane->seats }}</p>
    <p>Remaining seats : {{ $flight->airplane->seats - $flight->seats_taken }}</p>

    <form method="POST">
        @csrf
        <button type="submit">Buy Ticket</button>
    </form>
    <br>
    <table style="padding: 10px; border: 1px solid black">
        <thead>
            <th>Seat</th>
            <th>Person</th>
        </thead>
        <tbody>
            @foreach ($flight->seats as $seat)
            <tr style="padding: 10px; border: 1px solid black">
                <td style="padding: 10px; border: 1px solid black">Seat {{ $seat->seat_no }}</td>
                <td style="padding: 10px; border: 1px solid black">{{ $seat->user->name }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <br>
    @if (session()->has("admin"))
        <form method="POST">
            @csrf
            @method("DELETE")
            <input type="submit" value="Delete"/>
        </form>
    @endif
    <br>
    <a href="/home">Back</a>
</body>
</html>
