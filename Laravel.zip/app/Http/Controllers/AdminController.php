<?php

namespace App\Http\Controllers;

use App\Models\Airplane;
use App\Models\Flight;
use Illuminate\Http\Request;


class AdminController extends Controller
{
    public function login(){
        if (session()->get("admin") == true){
            return redirect("/admin/create");
        }
        return view("admin.login");
    }

    public function check_data(Request $req){
        if ($req->username == "anukrama" && $req->password == "anukrama"){
            session()->put("admin", true);
            return redirect("/admin/create");
        }
        return back()->with("message", "Incorrect Credrentials");
    }

    public function create(){
        if (!session()->has("admin") || !session()->get("admin") == true){
            return back();
        }
        $airplanes = Airplane::all();
        return view("admin.create", compact("airplanes"));
    }

    public function create_airplane(Request $request)
    {
        $data = $request->validate(Airplane::$rules);
        Airplane::create($data);
        return back()->with("message", "Airplane created !");
    }

    public function create_flight(Request $request)
    {
        $data = $request->validate(Flight::$rules);
        Flight::create($data);
        return back()->with("message", "Flight Created !");
    }
}
