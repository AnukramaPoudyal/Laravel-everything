<?php

namespace App\Http\Controllers;

use App\Models\Flight;
use App\Models\Seat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class FlightController extends Controller
{

    public function home()
    {
        $user = Auth::user();
        $flights = Flight::all();

        return view("home", compact("user", "flights"));

    }

    public function flight($id)
    {
        $flight = Flight::find($id);
        return view("flight", compact("flight"));
    }

    public function buy_seat($id)
    {
        $flight = Flight::find($id);

        if ($flight->seats_taken == $flight->airplane->seats)
        {
            return back()->with("message", 'Seats has finished !');
        }

        $flight->seats_taken = $flight->seats_taken + 1;
        $seat = new Seat();
        $seat->seat_no = $flight->seats_taken;
        $seat->user_id = Auth::user()->id;
        $seat->flight_id = $flight->id;
        $flight->save();
        $seat->save();
        return back()->with("message", "Seat bought sucessfully !");
    }

    public function delete_flight($id)
    {
        $flight = Flight::find($id);
        $flight->delete();
        return back()->with("message", "Deleted Sucessfully !");
    }
}
