<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Airplane extends Model
{
    use HasFactory;

    protected $fillable = [
        "name",
        "model",
        "type",
        "seats"
    ];

    public static $rules = [
        "name" => "required",
        "model" => "required",
        "type" => "required",
        "seats" => "required|numeric"
    ];

    public function flights()
    {
        return $this->hasMany(Flight::class, 'airplane_id');
    }
}
