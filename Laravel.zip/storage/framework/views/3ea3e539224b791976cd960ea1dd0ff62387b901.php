<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin</title>
</head>
<body>
    <h1>Admin</h1>
     <?php if(session()->has('message')): ?>
        <div><?php echo e(session()->get("message")); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <h2>Create Airplane</h2>
    <form method="POST" action="/admin/create/airplane">
        <?php echo csrf_field(); ?>
        <input name="name" placeholder="Name" required/><br>
        <input name="model" placeholder="Model" required><br>
        <select name="type" required>
            <option value="Domestic">Domestic</option>
            <option value="International">International</option>
        </select><br>
        <input name="seats" type="number" placeholder="No of Seats"><br><br>
        <input type="submit" value="Create">
    </form>
    <h2>Create Flight</h2>
    <form method="POST" action="/admin/create/flight">
        <?php echo csrf_field(); ?>
        <input name="from" placeholder="From" required><br>
        <input name="to" placeholder="To" required><br>
        <input name="price" placeholder="Price" type="number" required><br>
        <input name="time" type="time" required><br>
        <select name="airplane_id" required>
            <?php $__currentLoopData = $airplanes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airplane): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($airplane->id); ?>"><?php echo e($airplane->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <input type="submit" value="Create">
    </form>
</body>
</html>
<?php /**PATH /var/www/resources/views/admin/create.blade.php ENDPATH**/ ?>