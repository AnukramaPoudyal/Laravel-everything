<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>FlightManagement</title>
    </head>
    <body>
        <h4>Welcome <?php echo e($user->name); ?>,</h4>
        <p><?php echo e($user->email); ?></p>
        <form method="POST" action="/logout">
            <?php echo csrf_field(); ?>
            <input type="submit" value="Logout"/>
        </form>

        <?php $__currentLoopData = $flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="padding: 15px">
                <a href="/flight/<?php echo e($flight->id); ?>"> <?php echo e($flight->from); ?> to <?php echo e($flight->to); ?> in <?php echo e($flight->airplane->name); ?></a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </body>
</html>
<?php /**PATH /var/www/resources/views/home.blade.php ENDPATH**/ ?>