<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>FlightManagement</title>
    </head>
    <body>
        <h4>Welcome {{ $user->name }},</h4>
        <p>{{ $user->email }}</p>
        <form method="POST" action="/logout">
            @csrf
            <input type="submit" value="Logout"/>
        </form>

        @foreach ($flights as $flight)
            <div style="padding: 15px">
                <a href="/flight/{{ $flight->id }}"> {{ $flight->from }} to {{ $flight->to }} in {{ $flight->airplane->name }}</a>
            </div>
        @endforeach
    </body>
</html>
