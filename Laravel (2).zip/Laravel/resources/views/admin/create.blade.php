<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin</title>
</head>
<body>
    <h1>Admin</h1>
     @if (session()->has('message'))
        <div>{{ session()->get("message") }}</div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <h2>Create Airplane</h2>
    <form method="POST" action="/admin/create/airplane">
        @csrf
        <input name="name" placeholder="Name" required/><br>
        <input name="model" placeholder="Model" required><br>
        <select name="type" required>
            <option value="Domestic">Domestic</option>
            <option value="International">International</option>
        </select><br>
        <input name="seats" type="number" placeholder="No of Seats"><br><br>
        <input type="submit" value="Create">
    </form>
    <h2>Create Flight</h2>
    <form method="POST" action="/admin/create/flight">
        @csrf
        <input name="from" placeholder="From" required><br>
        <input name="to" placeholder="To" required><br>
        <input name="price" placeholder="Price" type="number" required><br>
        <input name="time" type="time" required><br>
        <select name="airplane_id" required>
            @foreach ($airplanes as $airplane)
                <option value="{{ $airplane->id }}">{{ $airplane->name }}</option>
            @endforeach
        </select><br><br>
        <input type="submit" value="Create">
    </form>
</body>
</html>
