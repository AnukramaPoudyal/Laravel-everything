<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>
    </head>
    <body>
        <h4>Welcome <?php echo e($user->name); ?>,</h4>
        <p><?php echo e($user->email); ?></p>
        <form method="POST" action="/logout">
            <?php echo csrf_field(); ?>
            <input type="submit" value="Logout"/>
        </form>
    </body>
</html>
<?php /**PATH /home/alpha/Documents/Laravel/bufferOverflow/resources/views/welcome.blade.php ENDPATH**/ ?>