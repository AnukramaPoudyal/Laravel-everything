<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Login</title>
</head>
<body>
    <?php if(session()->has('message')): ?>
        <div><?php echo e(session()->get("message")); ?></div>
    <?php endif; ?>
    <h1>Admin Login</h1>
    <form method="POST">
        <?php echo csrf_field(); ?>
        <input name="username" placeholder="Username"/><br>
        <input name="password" placeholder="Password" type="password"/><br>
        <input type="submit" value="Login"/>
    </form>
</body>
</html>
<?php /**PATH /home/alpha/Documents/Laravel/anukrama/resources/views/admin/login.blade.php ENDPATH**/ ?>