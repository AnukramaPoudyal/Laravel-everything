<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($flight->airplane->name); ?></title>
</head>
<body>

<?php if(session()->has('message')): ?>
    <div><?php echo e(session()->get("message")); ?></div>
<?php endif; ?>
    <h1><?php echo e($flight->from); ?> to <?php echo e($flight->to); ?> in <?php echo e($flight->airplane->name); ?></h1>
    <p>Flight Model : <?php echo e($flight->airplane->model); ?></p>
    <p>Flight Type : <?php echo e($flight->airplane->type); ?></p>
    <p>Time : <?php echo e($flight->time); ?></p>
    <p>Price : <?php echo e($flight->price); ?></p>
    <p>Total seats : <?php echo e($flight->airplane->seats); ?></p>
    <p>Remaining seats : <?php echo e($flight->airplane->seats - $flight->seats_taken); ?></p>

    <form method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit">Buy Ticket</button>
    </form>
    <br>
    <table style="padding: 10px; border: 1px solid black">
        <thead>
            <th>Seat</th>
            <th>Person</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $flight->seats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="padding: 10px; border: 1px solid black">
                <td style="padding: 10px; border: 1px solid black">Seat <?php echo e($seat->seat_no); ?></td>
                <td style="padding: 10px; border: 1px solid black"><?php echo e($seat->user->name); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <a href="/home">Back</a>
</body>
</html>
<?php /**PATH /home/alpha/Documents/Laravel/anukrama/resources/views/flight.blade.php ENDPATH**/ ?>