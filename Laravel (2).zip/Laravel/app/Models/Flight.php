<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Flight extends Model
{
    use HasFactory;

    protected $fillable = [
        "from",
        "to",
        "time",
        "airplane_id"
    ];

    public static $rules = [
        "from" => "required",
        "to" => "required",
        "price" => "required|numeric",
        "time" => "required",
        "airplane_id" => "required|numeric"
    ];

    public function airplane()
    {
        return $this->belongsTo(Airplane::class, 'airplane_id');
    }

    public function seats()
    {
        return $this->hasMany(Seat::class, "flight_id");
    }
}
